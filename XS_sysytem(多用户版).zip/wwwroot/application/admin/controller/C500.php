<?php
namespace app\admin\controller;
use think\Controller;
//网站后台系统设置
class C500 extends Controller
{
public function c500()
{
return $this->fetch('/c500');
}
}
